
#!/usr/bin/env python3
import sqlite3
import os

DB='people.db'

def init_db():
    conn=sqlite3.connect(DB)
    c=conn.cursor()
    c.execute('CREATE TABLE IF NOT EXISTS people (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)')
    conn.commit(); conn.close()

def add(name, age):
    conn=sqlite3.connect(DB); c=conn.cursor()
    c.execute('INSERT INTO people (name, age) VALUES (?,?)',(name,age))
    conn.commit(); conn.close()


def list_people():
    conn=sqlite3.connect(DB); c=conn.cursor()
    for row in c.execute('SELECT id, name, age FROM people'):
        print(row)
    conn.close()

if __name__=='__main__':
    init_db()
    import sys
    if len(sys.argv)<2:
        print('Usage: app.py [add/list]'); exit()
    cmd=sys.argv[1]
    if cmd=='add': add(sys.argv[2], int(sys.argv[3]))
    elif cmd=='list': list_people()
